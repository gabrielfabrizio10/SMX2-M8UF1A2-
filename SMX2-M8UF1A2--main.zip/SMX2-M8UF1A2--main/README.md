# **Evaluación inicial**

# SMX2-M8UF1A2-
Repositorio de evaluación

#¿Qué es una página web?

<font color='red'>rojo</font>Respuesta. Es un conjunto de información que un sitio web muestra en una pantalla, incluyendo a la totalidad de sus elementos


#¿Qué es un sitio web?

<font color='red'>rojo</font>Es un espacio virtual que contiene toda la información que una persona o empresa quiere difundir a través de internet. 

#¿Qué es una aplicación web?

<font color='red'>rojo</font> Respuesta.Es un software que se ejecuta en el navegador web


#¿Qué es una herramienta ofimática?

Respuesta.

Son aquellos programas o aplicaciones que nos permiten manipular informáticamente la información con la que se trabaja de forma habitual en una oficina.

#Herramientas de Google:

![tarea](https://github.com/gabrielfabrizio10/SMX2-M8UF1A2-/assets/145135376/73e25f4c-a466-41a2-82e8-443b1888113a)


#¿Qué es HTML ? 

Respuesta.

![tarea 2](https://github.com/gabrielfabrizio10/SMX2-M8UF1A2-/assets/145135376/0fe665bd-49cb-41b4-8ec8-c1afdf503c49)

Es el código que se utiliza para estructurar y desplegar una página web y sus contenidos

#¿Qué es CSS?


-Respuesta. Es un lenguaje de diseño gráfico para definir y crear la presentación de un documento estructurado escrito en un lenguaje de marcado </font>







#Flujo de trabajo (navegador, petición, servidor y respuesta):



![tarea 3](https://github.com/gabrielfabrizio10/SMX2-M8UF1A2-/assets/145135376/618b5302-c823-426f-848d-cca698377f2b)


